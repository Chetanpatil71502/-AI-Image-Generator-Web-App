const apiKey = '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'; 
const model = 'black-forest-labs/FLUX.1-schnell'; 

async function generateImages() {
  const prompt = document.getElementById('prompt').value;
  const numImages = parseInt(document.getElementById('num-images').value, 10);
  const style = document.getElementById('style').value;

  if (!prompt || numImages < 1 || numImages > 10) {
    alert('Please provide a valid prompt and number of images.');
    return;
  }

  const finalPrompt = style ? `${prompt}, in style of ${style}` : prompt;

  const imagesContainer = document.getElementById('images-container');
  const loadingSpinner = document.getElementById('loading-spinner');

  loadingSpinner.classList.remove('hidden');
  imagesContainer.innerHTML = '';

  const requests = Array.from({ length: numImages }, () => fetchImage(finalPrompt));

  try {
    const images = await Promise.all(requests);
    images.forEach(imgSrc => {
      const imgWrapper = document.createElement('div');
      imgWrapper.classList.add('relative', 'max-w-xs', 'img-card');

      const img = document.createElement('img');
      img.src = imgSrc;
      img.classList.add('object-cover', 'rounded-xl', 'shadow-lg', 'w-72', 'h-72');

      const downloadBtn = document.createElement('a');
      downloadBtn.href = imgSrc;
      downloadBtn.download = 'image.png';
      downloadBtn.textContent = '⬇️ Download';
      downloadBtn.classList.add('mt-3', 'block', 'bg-blue-500', 'text-white', 'px-3', 'py-1', 'rounded-md', 'text-center', 'hover:bg-blue-600', 'transition', 'duration-300');

      imgWrapper.appendChild(img);
      imgWrapper.appendChild(downloadBtn);
      imagesContainer.appendChild(imgWrapper);
    });
  } catch (error) {
    console.error('Error generating images:', error);
    alert('Failed to generate images. Please try again.');
  } finally {
    loadingSpinner.classList.add('hidden');
  }
}

async function fetchImage(prompt) {
  const response = await fetch(`https://api-inference.huggingface.co/models/${model}`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ inputs: prompt })
  });

  if (!response.ok) throw new Error('Failed to fetch image');

  const result = await response.blob();
  return URL.createObjectURL(result);
}

// Dark Mode Toggle
document.getElementById('toggleDark').addEventListener('click', () => {
  document.getElementById('body').classList.toggle('dark');
});

// GSAP Animation
gsap.from("#navLogo", {
  duration: 1.5,
  opacity: 0,
  y: -50,
  ease: "power3.out"
});
